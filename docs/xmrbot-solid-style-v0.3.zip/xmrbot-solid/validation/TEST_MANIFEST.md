# Collected tests

```text
tests/test_api.py: 8
tests/test_blog.py: 2
tests/test_compatibility.py: 1
tests/test_content.py: 1
tests/test_economics.py: 5
tests/test_hardware.py: 2
tests/test_knowledge.py: 3
tests/test_machine_discovery.py: 3
tests/test_mcp.py: 6
tests/test_rpc.py: 1
tests/test_security.py: 3
tests/test_style.py: 2
tests/test_xmrcomputer_bridge.py: 1

```
